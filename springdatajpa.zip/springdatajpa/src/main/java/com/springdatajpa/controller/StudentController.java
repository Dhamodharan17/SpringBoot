package com.springdatajpa.controller;

import com.springdatajpa.modal.Student;
import com.springdatajpa.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class StudentController {
    StudentService studentservice;

    @Autowired
    public StudentController(StudentService studentservice) {
        this.studentservice = studentservice;
    }

    @GetMapping(value = "/students")
    public List<Student> getAllStudents() {
        return studentservice.getAllStudents();
    }

    @GetMapping(value = "/students/{id}")
    public Optional<Student> getStudentById(@PathVariable("id")  int id) throws Exception {
        Optional<Student> std = studentservice.findById(id);
        return std;
    }

    @PostMapping(value = "/students")
    public Student addStudent( @RequestBody Student std) {
        return studentservice.save(std);
    }


    @DeleteMapping(value = "/students/{id}")
    public String deleteStudent(@PathVariable("id") int id) throws Exception {
        Student std = studentservice.findById(id).
                orElseThrow(() -> new Exception("Student with " + id + " is Not Found!"));
        studentservice.deleteById(std.getId());
        return "Student with ID :" + id + " is deleted";
    }
}